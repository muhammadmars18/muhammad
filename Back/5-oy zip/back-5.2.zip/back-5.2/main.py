import sqlite3


aloqa = sqlite3.connect("baza.db")
kursor = aloqa.cursor()

sql_kod = '''
CREATE TABLE IF NOT EXISTS students (
    ism text,
    familiya text,
    yosh int,
    guruh text,
):
'''

sql_kod = '''
INSERT INTO students(ism,familya,yosh,guruh)
VALUES
('Abdulvoris', 'Bahtiyorov', 12, '1145')
('Aziz', 'Anvarov', 14, '1145')
'''