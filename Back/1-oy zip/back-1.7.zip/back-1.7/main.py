# a = input('1-chi sonni kiriting: ')
# b = input('2-chi sonni kiriting: ')
# c = input('3-chi sonni kiriting: ')
# a, b, c = int(a), int(b), int(c)

# if a > c and a > b:
#     print(a, 'eng katta son!')
# elif c > a and c > b:
#     print(c, "eng katta son!")
# elif b > a and b > c:
#     print(b, "eng katta son!")
# elif a == c and c == b and a == b:
#  print("Hamma sonlar teng!")
# elif a == b > c:
#  print("1-son va 2-son sonlari teng 3-son kichik")
# elif a == b < c:
#  print("1-son va 2-son sonlari teng 3-son katta")
# elif a > b == c:
#    print("2-son va 3-son sonlari teng 1-son katta")
# elif a < b == c:
#    print("2-son va 3-son sonlari teng 1-son kichik")


# a = input('1-chi sonni kiriting: ')
# b = input('2-chi sonni kiriting: ')
# c = input('3-chi sonni kiriting: ')
# d = input('4-chi sonni kiriting: ')
# a, b, c, d = int(a), int(b), int(c), int(d)

# manfiylari_soni = 0
# if a < 0:
#     manfiylari_soni = manfiylari_soni + 1
# if b < 0:
#     manfiylari_soni = manfiylari_soni + 1
# if c < 0:
#     manfiylari_soni = manfiylari_soni + 1
# if d < 0:
#     manfiylari_soni = manfiylari_soni + 1
# print(manfiylari_soni ,"ta manfiy son bor")
# a = input("kod kiriting: ")
# if 1 :
#     print('siz 05 pepsini oldingiz HARIDINGIZ UCHUN RAXMAT')
    


# elif 2:
#     print('siz 05 coca cola oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 3:
#     print('siz 05 fanta  oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 4:
#     print('siz 05 sprayt oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 5:
#     print('siz 05 laim fresh oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 6:
#     print('siz 05 dinay  oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 7:
#     print('siz 05 fuistiy oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 8:
#     print('siz 05 liptim  oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 9:
#     print('siz 05 7 up oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 10:
#     print('siz 05 mirinda oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 11:
#     print('siz 05 suv oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 12:
#     print('siz 05 gazli suv oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 13:
#     print('siz bauntiy HARIDINGIZ UCHUN RAXMAT')
# elif 14:
#     print('siz snikers oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 15:
#     print('siz 05 tviks oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 16:
#     print('siz  milki vey oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 17:
#     print('siz kit kat oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 18:
#     print('siz alpen gold oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 19:
#     print('siz maks fan oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 20:
#     print('siz milenium oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 21:
#     print('siz biskolata oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 22:
#     print('siz mega pista oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 23:
#     print('siz ermak pista oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 24:
#     print('siz  mega qurt oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 25:
#     print('siz ermak qurt oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 26:
#     print('siz flint oldingiz oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 27:
#     print('siz lays  oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 28:
#     print('siz cheers oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 29:
#     print('siz  pringls oldingiz HARIDINGIZ UCHUN RAXMAT')
# elif 30:
#     print('siz 0,33 red bul oldingiz HARIDINGIZ UCHUN RAXMAT')
    

# hafta_kuni = int(input("Iltimos, hafta kunining raqamini kiriting (1 dan 7 gacha): ")).strip().lower

# if hafta_kuni == 1:
#     print("Dushanba")
# elif hafta_kuni == 2:
#     print("Seshanba")
# elif hafta_kuni == 3:
#     print("Chorshanba")
# elif hafta_kuni == 4:
#     print("Payshanba")
# elif hafta_kuni == 5:
#     print("Juma")
# elif hafta_kuni == 6:
#     print("Shanba")
# elif hafta_kuni == 7:
#     print("Yakshanba")
# else:
#     print("Noto'g'ri raqam kiritdingiz. 1 dan 7 gacha bo'lgan raqam kiriting.")


# kanikul_oyi = int(input("Iltmos hozirgi oyni raqamini kiriting:  ")).strip().lower
# if kanikul_oyi == 6:
#     print('Hozir yozgi ta\'til vaqti')
# elif kanikul_oyi == 6:
#     print('Hozir yozgi ta\'til vaqti')
# elif kanikul_oyi == 6:
#     print('Hozir yozgi ta\'til vaqti')
# else:
#     print('Hozir o\'qish vaqti')


# svetafor_rangi = int(input('Svetafor rangini kiriting: ')).strip().lower()
# if svetafor_rangi == 'yashil':
#     print('Yuring')
# elif svetafor_rangi == 'sariq':
#     print('Tayyorlaning')
# elif svetafor_rangi == 'qizil':
#     print('To\'tang')
# else:
#     print("svetaforda bunday rang yo\'q")



