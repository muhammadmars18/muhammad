# ob_havo =  input("ob-havoni kiriting: ")
# if ob_havo == 'issiq':
#     print("yuqaro kiyn ")
# elif ob_havo == 'iliq':
#     print("yuqaro kiyin")
# elif ob_havo == 'sovuq':
#     print('qalinro kiyin')
# elif ob_havo == 'yomgirli':
#     print("yomg'irga mos kiyin")
# elif ob_havo == 'qorli':
#     print("qorga mos kiyin")

username = "superuser"
password = "salom123"

input_username = input("Username kiriting: ")
input_password = input("Password kiriting: ")

if input_username == username and input_password == password:
    print("Xush kelibsiz")
else:
    print("Username yoki password xato")
def juft_toq(son):
    if son % 2 == 0:
        return "Juft son"
    else:
        return "Toq son"

input_number = int(input("Biror son kiriting: "))
print(juft_toq(input_number))


