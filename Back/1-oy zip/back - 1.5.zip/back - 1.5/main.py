# import math
# a = input("1-sonni kiriting")
# n = input("2-sonni kiriting")
# a= int(a)
# n=int(n)
# print(
#     math.pow(a,n)
# )

# 4
# a = 5
# b = 1
# print(a>2,b<3 )

# 5
# a = 1
# b = -3
# print(a>0, b<-2)


# 6
# a = 1
# b = 2
# c = 3
# a = 3
# b = 2
# c = 1
# print(a<b<c)

matn = "Bu bir matn misoli"

print(matn)

print(matn.upper())

print(matn.lower())

print(matn.capitalize())

print(matn.strip())

print(matn.title())

