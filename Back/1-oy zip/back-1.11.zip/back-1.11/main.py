'''
foydalanuvchidan parol yaratishini so'rang
va parol 8 ta belgidan kam bo'lsa 
yana qaytadan kiritishini so'rang
agar parol 8 ta belgi yoki undan ko'p bo'lsa 
sikldan chiqib keting
'''
# print('parol yarating u 8 ta belgidan kam bolmasligi kerak')
# parol = input('parol: ')

# while len(parol) < 8:
#     parol = input('parol: ')

# print('congratulations!')



# parol = 'banana'
# user = input('maxfiy so\'zni kiriting: ')

# while user != parol:
#     user = input('maxfiy so\'zni kiriting: ')

# print('topdiz')

# while True:
#     print("Iltimos, 2 ta son kiriting:")
#     try:
#         a = float(input("Birinchi son: "))
#         b = float(input("Ikkinchi son: "))
#     except ValueError:
#         print("Noto'g'ri son kiritdingiz. Iltimos, qaytadan urunib ko'ring.")
#         continue

#     print("Iltimos, amalni tanlang:")
#     print("1. Qo'shish")
#     print("2. Ayirish")
#     print("3. Ko'paytirish")
#     print("4. Bo'lish")

#     belgi = input("Tanlangan amalning raqamini kiriting (1/2/3/4): ")

#     if belgi == '1':
#         print("Natija:", a + b)
#     elif belgi == '2':
#         print("Natija:", a - b)
#     elif belgi == '3':
#         print("Natija:", a * b)
#     elif belgi == '4':
#         if b != 0:
#             print("Natija:", a / b)
#         else:
#             print("Nolga bo'lish mumkin emas")
#     else:
#         print("Noto'g'ri amalni tanladingiz. Iltimos, qaytadan urunib ko'ring.")

#     javob = input("Davom etasizmi? (ha/yuq): ")
#     if javob.lower() != 'ha':
#         break





i = 1
while i <= 10:
    print(i, end=", ")
    i += 1

print("\n")





# num = int(input("Istalgan son kiriting: "))
# while num >= 1:
#     print(num, end=", ")
#     num -= 1

# print("\n")





# n = int(input("Istalgan son kiriting: "))
# total = 0
# i = 1
# while i <= n:
#     total += i
#     i += 1
# print("Yig'indisi:", total)

# print("\n")






# total = 0
# while True:
#     num = int(input("Son kiriting (0 dan tashqari): "))
#     if num == 0:
#         break
#     total += num

# print("Yig'indisi:", total)
   