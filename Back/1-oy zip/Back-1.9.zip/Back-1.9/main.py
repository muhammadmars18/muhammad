
# for i in range(100, -2,-1):
#  print(i)

# for i in range(8):
#     print()
# yegindi = 0
# for i in range(1, 100,2):
#     yegindi = yegindi + i
#     print(f"yigindi = {yegindi}")


# son = int(input("Iltimos, son kiriting: "))
# summa = 0

# for i in range(1, son + 1):
#     summa += i

# print(f"Input: {son}. Output: {summa}")


# matn = input("Matn kiriting: ")
# bosh_harf = matn[0]
# kichik_harflar = matn[1:].lower()

# print(f'Input: "{matn}". Output: "{bosh_harf}", "{kichik_harflar}"')


# matn = input("Matn kiriting: ")
# bosh_harf = matn[0]
# kichik_harflar = matn[1:].lower()
# harf_soni = len(matn)

# print(f'Input: "{matn}". Output: "{bosh_harf} => {len(bosh_harf)}ta", "{kichik_harflar} => {harf_soni}ta"')


# matn = input("Matn kiriting: ")
# bosh_harf = matn[0]
# kichik_harflar = matn[1:].lower()
# harf_soni = len(matn)

# raqamlar = [harf for harf in matn if harf.isdigit()]
# raqam_soni = len(raqamlar)

# print(f'Input: "{matn}". Output: "{bosh_harf} => {len(bosh_harf)}ta", "{kichik_harflar} => {harf_soni}ta", "{"".join(raqamlar)} => {raqam_soni}ta"')
