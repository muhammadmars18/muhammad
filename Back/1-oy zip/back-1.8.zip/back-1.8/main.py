# son = int(input('son: '))

# if 2 <= son <=20:
#     print('false')
# else:
#     print('true')



# text = input('text kiriting: ')

# harf = 0

# for i in text:
#   if harf =='a':
#    harf+=1
#    print('kiritilgan textda',{a},'ta a harfi bor')




# ob_havo =  input("ob-havoni kiriting: ")
# if ob_havo  > 0:
#     print("Juda sovuq! ")
# elif ob_havo > 30:
#     print("Juda issiq!")
# else:
#     print("Havo harorati qulay")




# ball = input('balni kiriting: ')
# ball = int(ball)

# if ball >= 90:
#     print("Juda Ajoyib")
# elif ball >= 80:
#     print("Yaxshi")
# elif ball >= 70:
#     print("O'rtacha")
# elif ball >= 60:
#     print(":(")
# else:
#     print("O'tolmadiz :><)")
