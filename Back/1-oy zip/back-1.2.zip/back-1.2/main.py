ovqat1 = 'osh'
ovqat1_narxi = 23000
ovqat2 = 'shashli'
ovqat2_narxi = 15000
ovqat3 = 'qozon kabob'
ovqat3_narxi = 36000
ovqat4 = 'xalim'
ovqat4_narxi = 25000
ovqat5 = 'mastava'
ovqat5_narxi = 30000

print(ovqat1,"--",ovqat1_narxi)
print(ovqat2,"--",ovqat2_narxi)
print(ovqat3,"--",ovqat3_narxi)
print(ovqat4,"--",ovqat4_narxi)
print(ovqat5,"--",ovqat5_narxi)





# son1 =input( "1-sonni kiriting")
# son2 =input ("2-sonii kiriting")

# son1 =int(son1) 
# son2 =int(son2) 
# print(son1 + son2)

# print('''
#   |------------------------- |
#   | Foydalanuvchi malumotlari|
#  ====**************************====
# ''')
# ism = input("Ismingizni kiriting: ")
# familya = input("Familyangizni kiriting: ")
# yosh = input("Yoshingizni kiriting: ")
# email = input("Elektron pochtangizni kiriting: ")
# yil = input("Tug'ilgan yili,oy,sanangizni kiriting: ")
# Adress = input ("Yashash mazilingizni kiriting: ")
# print('''
# ====**************************====''')