

names = [1,2,3,4,5,]
names.append(6)

fruit = ['apple,watermelon,melon']
nimadur = names + fruit
print(nimadur)











# nums = [2, 6, 5, 8, 3, 5, 4]
# number1 = max(nums)
# print(number1)

# number2 = min(nums)
# print(number2)

# reverse_sorted_nums = sorted(nums, reverse=True)
# print(reverse_sorted_nums)

# sorted_nums = sorted(nums)
# print(sorted_nums)

# num_count = len(nums)
# print(num_count)
