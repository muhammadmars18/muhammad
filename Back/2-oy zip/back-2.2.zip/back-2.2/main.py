# 1 - append va extend
#     - my_list nomli bo'sh ro'yhat yarating
#     - 1, 2 va 3 sonlarini append orqali listga qo'shing
#     - 4, 5, 6 sonlarini o'z ichiga olgan listni
#       extend yordamida my_list ga qo'shing

# 2 - remove va pop
#     - 10, 20, 30, 40, 50 larni o'z ichiga olgan
#       numbers listini yarating
#     - listdan 30 raqamini olib tashlang
#     - listdan 2-chi indeksda turgan elementni olib tashlang


# my_list = []
# my_list.append(1,2,3)
# my_list.extend([4,5,6])
# print(my_list)


# numbers  = [10, 20, 30, 40, 50]
# numbers.remove(30)
# numbers.pop(2)
# print(numbers)



my_list = []

my_list.append(1)
my_list.append(2)
my_list.append(3)
my_list.append(4)
my_list.append(5)

print("1. Ro'yxat:", my_list)

names = ["Alex", "John", "Emily", "Alex", "Daniel"]

index_of_Alex = names.index("Alex")

print("2. Indeks:", index_of_Alex)

countries = ["USA", "China", "India"]

countries.insert(1, "Russia")

print("3. Yangi ro'yxat:", countries)

numbers = [10, 20, 30, 40, 50]

numbers.pop()

# Olingan ro'yxatni ko'rsatish
print("4. O'chirilgan ro'yxat:", numbers)

# 5. Remove() uchun vazifa
# Ikki nusxadagi elementlarni o'z ichiga olgan ro'yxat
duplicates = [1, 2, 3, 2, 4, 1, 2]

# Ro'yxatdan 2 raqamini olib tashlash
duplicates.remove(2)

# Olingan ro'yxatni ko'rsatish
print("5. O'chirilgan ro'yxat:", duplicates)

# 6. Birlashtirilgan vazifa
# Bo'sh ro'yxat yaratish
merged_list = []

# Ro'yxatga besh xil nom qo'shish
merged_list.append("Alex")
merged_list.append("John")
merged_list.append("Emily")
merged_list.append("Alex")
merged_list.append("Daniel")

# index() usulidan foydalanib, "Anna" nomining indeksini topish
index_of_Anna = merged_list.index("Anna")

# insert() usulidan foydalanib, qolgan nomlarning indekslarini oshirib, indeks o`rniga «Meri» nomini qo`ying
merged_list.insert(index_of_Anna, "Meri")

# pop() usulidan foydalanib, uchinchi nomni ro`yxatdan olib tashlang
merged_list.pop(2)

# Remove() usulidan foydalanib, "Anna" nomini ro'yxatdan olib tashlang
merged_list.remove("Anna")

# Olingan ro'yxatni ko'rsatish
print("6. O'zgartirilgan ro'yxat:", merged_list)